package com.unisales.contabancaria.controllers.authcontroller;

import com.unisales.contabancaria.domain.user.User;
import com.unisales.contabancaria.exceptions.UserAlreadyExistsException;
import com.unisales.contabancaria.services.authservice.AuthService;
import com.unisales.contabancaria.services.userservice.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User loginUser) {
        if (authService.authenticate(loginUser)) {
            return ResponseEntity.ok("Autenticado com sucesso");
        } else {
            return ResponseEntity.status(401).body("Usuário não encontrado ou senha incorreta");
        }
    }

    @PostMapping("/registro")
    public ResponseEntity<?> createUser(@RequestBody User user) {
        try {
            User newUser = userService.createUser(user);
            return ResponseEntity.ok(newUser);
        } catch (UserAlreadyExistsException e) {
            return ResponseEntity.status(400).body("Usuário já existe no sistema");
        }
    }
}