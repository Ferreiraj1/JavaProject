package com.unisales.contabancaria.exceptions;

public class ContaBancariaAlreadyExistsException extends Exception {
    public ContaBancariaAlreadyExistsException(String message) {
        super(message);
    }
}