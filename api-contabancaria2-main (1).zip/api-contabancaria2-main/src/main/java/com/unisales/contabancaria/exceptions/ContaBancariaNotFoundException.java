package com.unisales.contabancaria.exceptions;

public class ContaBancariaNotFoundException extends Exception {
    public ContaBancariaNotFoundException(String message) {
        super(message);
    }
}