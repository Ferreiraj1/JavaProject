package com.unisales.contabancaria.services.authservice;

import com.unisales.contabancaria.domain.user.User;
import com.unisales.contabancaria.domain.user.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    public boolean authenticate(User loginUser) {
        Optional<User> optionalUser = userRepository.findByEmail(loginUser.getEmail());
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            return passwordEncoder.matches(loginUser.getSenha(), user.getSenha());
        }
        return false;
    }
}