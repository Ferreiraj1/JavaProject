package com.unisales.contabancaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContabancariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
